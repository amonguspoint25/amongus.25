GameWatcher Ranked - Among Us host mod (host-only)

INSTALL
1. Close Among Us.
2. Extract the CONTENTS of this folder into your Among Us folder
   (the folder that contains "Among Us.exe").
   Steam: ...\steamapps\common\Among Us
3. Launch Among Us once and wait ~30s at the main menu. The first launch builds
   the game-interface files (BepInEx\interop) - this is normal and one-time.
4. Get your host key at https://au-25.vercel.app/host and set it:
     run "Set Host Key.bat"
   (or edit BepInEx\config\com.amongus25.gamewatcher.cfg -> HostKey = <your key>)
5. Host a lobby and type /ranked on. Ranked starts only when the lobby settings
   match the ranked preset and every player is linked.

NOTES
- Only the LOBBY HOST needs this mod.
- Requires the ranked Among Us build (same version everyone plays on).
- Your host key is personal - do not share it.
